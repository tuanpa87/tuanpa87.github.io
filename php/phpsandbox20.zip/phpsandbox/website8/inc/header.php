<!DOCTYPE html>
	<html>
		<head>
			<title>PHP Blog</title>
			<link rel="stylesheet" type="text/css" href="http://bootswatch.com/cerulean/bootstrap.min.css">
		</head>
	<body>
	<?php include('navbar.php'); ?>