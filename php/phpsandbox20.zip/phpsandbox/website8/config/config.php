<?php
	define('ROOT_URL', 'http://localhost/phpsandbox/website8/');
	define('DB_HOST', 'localhost');
	define('DB_USER', 'root');
	define('DB_PASS', '123456');
	define('DB_NAME', 'phpblog');