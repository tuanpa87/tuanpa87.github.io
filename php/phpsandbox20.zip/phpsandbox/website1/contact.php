<?php include('inc/header.php'); ?>
	<h1>Contact</h1>
<?php include 'inc/footer.php'; ?>