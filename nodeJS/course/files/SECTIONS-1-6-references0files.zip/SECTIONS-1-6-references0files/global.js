var path = require('path');


var name = "Edwin Diaz";
var newName = name.toUpperCase(name);

console.log(`newName variable is ${newName}`);


console.log(__dirname);

console.log(path.basename(__filename));





