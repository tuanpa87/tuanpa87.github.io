const object = require('./lib');


console.log(object.someProperty);