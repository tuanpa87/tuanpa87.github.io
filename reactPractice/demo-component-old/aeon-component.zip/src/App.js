import React, { Component } from 'react';
import './App.css';
import Cards from './containers/Cards/Cards';

class App extends Component {
  render() {
    return (
      <div className="App">
        <Cards />
      </div>
    );
  }
}

export default App;
